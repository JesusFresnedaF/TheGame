/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package localgame;

import java.awt.GridBagLayout;
import javax.swing.JPanel;

/**
 *
 * @author jesus
 */
public class ControlPanel extends JPanel{

    public ControlPanel() {
        this.setLayout(new GridBagLayout());
    }
    
}
