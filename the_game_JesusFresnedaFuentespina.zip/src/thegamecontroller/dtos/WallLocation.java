/*
    Enum de la localización de los muros
 */
package thegamecontroller.dtos;

import java.io.Serializable;

/**
 *
 * @author jesus
 */
public enum WallLocation implements Serializable{
    NORTH, SOUTH, EAST, WEST;
}
