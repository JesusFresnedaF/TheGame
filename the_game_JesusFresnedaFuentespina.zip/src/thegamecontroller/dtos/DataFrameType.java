/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package thegamecontroller.dtos;

/**
 *
 * @author jesus
 */
public enum DataFrameType {
    APLICATION_FRAME, FRAME_REFUSED, INTERNAL_INFO, KEEP_ALIVE, KEEP_ALIVE_ACK;
}
