/*
    Enum de los estados de los objetos visuales
 */
package thegamecontroller.dtos;

import java.io.Serializable;

/**
 *
 * @author jesus
 */
public enum VODState implements Serializable {
    ALIVE, DEAD, PAUSE;
}
