/*
    Enum de los estados de la puerta
 */
package thegamecontroller.dtos;

import java.io.Serializable;

/**
 *
 * @author jesus
 */
public enum GateState implements Serializable {
    OPEN, CLOSED;
}
