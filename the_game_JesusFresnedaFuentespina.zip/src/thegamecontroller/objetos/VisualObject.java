/*
    Clase de objetos visuales
 */
package thegamecontroller.objetos;

import java.awt.Graphics;
import java.io.Serializable;

/**
 *
 * @author jesus
 */
public class VisualObject implements Serializable {

    public VisualObject() {
    }

    public void pintar(Graphics g) {
    }
}
